<?php
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
	include '../db_connection.php';
    include '../includes/auth.php';
    
    if(isset($_POST)){
        $adharCard = $_POST['adharCard'];
            //query for fetch data  froQuickResponses table According to status value
            $data = $db->query("SELECT * FROM QuickResponses  WHERE Status = ?",$StatusQR )->fetchAll();   
       
        echo json_encode(array("QuickResponsesMessages" => $data));
        exit;
      }
 
// ?>