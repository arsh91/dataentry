<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Dashboard</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
<?php
    include '../db_connection.php';
	include '../includes/css.php';
    include '../includes/auth.php';

?>
</head>
</body>
<main id="main" class="main">
        <!-- Navigation -->
        <?php
            include '../includes/header.php';
        ?>
        <!-- Navigation -->
        <div class="pagetitle">
            <h1>Dashboard</h1>
        </div><!-- End Page Title -->
        <section class="section">
            <div class="row">
               <div class="col-md-12">
                </div>
            </div>
        </section>
    </main>
<?php
	include '../includes/js.php';
?>
</body>
</html>